$ui.render("main");

// sync from jsbox for vscode